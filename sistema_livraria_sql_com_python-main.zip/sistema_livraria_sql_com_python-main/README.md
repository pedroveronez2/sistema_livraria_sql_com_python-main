# sistema_livraria_sql_com_python
Este é um pequeno sistema de banco de dados utilizando o python para fazer um cliente comprar um livro
